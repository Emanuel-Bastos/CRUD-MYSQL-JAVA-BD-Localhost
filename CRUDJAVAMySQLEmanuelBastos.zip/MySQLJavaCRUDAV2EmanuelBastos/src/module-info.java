/**
 * 
 */
/**
 * 
 */
module MySQLJavaCRUDAV2EmanuelBastos {
	requires java.sql;
}